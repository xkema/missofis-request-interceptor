/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	var parentJsonpFunction = window["webpackJsonp"];
/******/ 	window["webpackJsonp"] = function webpackJsonpCallback(chunkIds, moreModules, executeModules) {
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [], result;
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId])
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(chunkIds, moreModules, executeModules);
/******/ 		while(resolves.length)
/******/ 			resolves.shift()();
/******/ 		if(executeModules) {
/******/ 			for(i=0; i < executeModules.length; i++) {
/******/ 				result = __webpack_require__(__webpack_require__.s = executeModules[i]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	};
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// objects to store loaded and loading chunks
/******/ 	var installedChunks = {
/******/ 		3: 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/ 	// This file contains only the entry chunk.
/******/ 	// The chunk loading function for additional chunks
/******/ 	__webpack_require__.e = function requireEnsure(chunkId) {
/******/ 		if(installedChunks[chunkId] === 0)
/******/ 			return Promise.resolve();
/******/
/******/ 		// an Promise means "currently loading".
/******/ 		if(installedChunks[chunkId]) {
/******/ 			return installedChunks[chunkId][2];
/******/ 		}
/******/ 		// start chunk loading
/******/ 		var head = document.getElementsByTagName('head')[0];
/******/ 		var script = document.createElement('script');
/******/ 		script.type = 'text/javascript';
/******/ 		script.charset = 'utf-8';
/******/ 		script.async = true;
/******/ 		script.timeout = 120000;
/******/
/******/ 		if (__webpack_require__.nc) {
/******/ 			script.setAttribute("nonce", __webpack_require__.nc);
/******/ 		}
/******/ 		script.src = __webpack_require__.p + "" + chunkId + ".bundle.js";
/******/ 		var timeout = setTimeout(onScriptComplete, 120000);
/******/ 		script.onerror = script.onload = onScriptComplete;
/******/ 		function onScriptComplete() {
/******/ 			// avoid mem leaks in IE.
/******/ 			script.onerror = script.onload = null;
/******/ 			clearTimeout(timeout);
/******/ 			var chunk = installedChunks[chunkId];
/******/ 			if(chunk !== 0) {
/******/ 				if(chunk) chunk[1](new Error('Loading chunk ' + chunkId + ' failed.'));
/******/ 				installedChunks[chunkId] = undefined;
/******/ 			}
/******/ 		};
/******/
/******/ 		var promise = new Promise(function(resolve, reject) {
/******/ 			installedChunks[chunkId] = [resolve, reject];
/******/ 		});
/******/ 		installedChunks[chunkId][2] = promise;
/******/
/******/ 		head.appendChild(script);
/******/ 		return promise;
/******/ 	};
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// on error function for async loading
/******/ 	__webpack_require__.oe = function(err) { console.error(err); throw err; };
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/** Utilities for Interceptor */
var Utils = function () {
  function Utils() {
    _classCallCheck(this, Utils);
  }

  _createClass(Utils, null, [{
    key: 'updateExtensionData',


    /**
     * Updates extension storage data
     * @param {object} items - Data collection 
     */
    value: function updateExtensionData(items) {
      self = this;
      chrome.storage.sync.set(items, function () {
        if ('undefined' !== typeof items.interceptorStatus) {
          self._updateBadgeStatus(items.interceptorStatus);
        }
      });
    }

    /**
     * Updates extension options
     * @param {object} items - Data collection
     * @param {function} optionsUpdatedCallback - Calback after options update
     */

  }, {
    key: 'updateExtensionOptions',
    value: function updateExtensionOptions(items, optionsUpdatedCallback) {
      chrome.storage.sync.set(items, function () {
        // console.log('OPTIONS UPDATED ::', 'items', optionsUpdatedCallback);
        if (typeof optionsUpdatedCallback !== 'undefined' && typeof optionsUpdatedCallback === 'function') {
          optionsUpdatedCallback.call(this, items);
        }
      });
    }

    /**
     * Get extension storage data
     * @param {mixed} keys - Data keys to be fetched (pass null to retrieve all extension data)
     * @param {function} dataReadyCallback - Calback after data retrival. 
     */

  }, {
    key: 'readExtensionData',
    value: function readExtensionData(keys, dataReadyCallback) {
      self = this;
      chrome.storage.sync.get(keys, function (items) {
        if (typeof dataReadyCallback !== 'undefined' && typeof dataReadyCallback === 'function') {
          dataReadyCallback.call(this, items);
        }
        self._updateBadgeStatus(items.interceptorStatus);
      });
    }

    /**
     * Send single message to extension with toggle button status data
     * @param {object} data - Toggle button status data
     */

  }, {
    key: 'sendTogglerMessage',
    value: function sendTogglerMessage(data) {
      chrome.runtime.sendMessage(data, function (response) {
        // console.log('DATA RESPONSE FROM UTILS.JS ::', response);
      });
    }

    /**
     * Send single message to extension with options data
     * @param {object} data - Options data
     */

  }, {
    key: 'sendOptionsMessage',
    value: function sendOptionsMessage(data) {
      chrome.runtime.sendMessage(data, function (response) {
        // console.log('DATA RESPONSE FROM UTILS.JS ::', response);
      });
    }

    /**
     * Updates background app local state object
     * @param {object} items - Updated items
     * @param {object} currentState - Current state
     */

  }, {
    key: 'updateLocalState',
    value: function updateLocalState(items, currentState) {
      if ('undefined' !== typeof items.interceptorStatus) {
        currentState.interceptorStatus = items.interceptorStatus;
      }
      if ('undefined' !== typeof items.placeholdersStatus) {
        currentState.placeholdersStatus = items.placeholdersStatus;
      }
      if ('undefined' !== typeof items.redirectsInterceptor) {
        currentState.redirectsInterceptor = items.redirectsInterceptor;
      }
      if ('undefined' !== typeof items.redirectsInterceptorPlain) {
        currentState.redirectsInterceptorPlain = items.redirectsInterceptorPlain;
      }
      if ('undefined' !== typeof items.redirectsImageHinters) {
        currentState.redirectsImageHinters = items.redirectsImageHinters;
      }
      if ('undefined' !== typeof items.redirectsImageHintersPlain) {
        currentState.redirectsImageHintersPlain = items.redirectsImageHintersPlain;
      }
    }

    /**
     * Parses user input for redirection options
     * @param {string} redirects - All data from textarea option
     * @return 
     */

  }, {
    key: 'parseRedirectUrls',
    value: function parseRedirectUrls(redirects) {
      var hasParserError = false,
          lines = this._findLineBreaks(redirects);
      // return request/redirect pairs for url intercepting
      var interceptedUrls = lines.map(function (redirect) {
        var redirectPartials = redirect.split(/\s+/g);
        if (2 !== redirectPartials.length) {
          // console.log('PARSER ERROR :: MALFORMED REDIRECTION INPUT');
          hasParserError = true;
        }
        return {
          redirectUrl: redirectPartials[0], // string to be replaced with `requestUrl`
          requestUrl: redirectPartials[1] // url to be requested
        };
      });
      if (hasParserError) {
        return hasParserError; // return error object instead
      } else {
        return interceptedUrls;
      }
    }

    /**
     * Parses user input for redirection options
     * @param {string} hinters - All data from textarea option for image hinters
     * @return 
     */

  }, {
    key: 'parseImageHinters',
    value: function parseImageHinters(hinters) {
      var hasParserError = false,
          lines = this._findLineBreaks(hinters);
      lines.forEach(function (line) {
        if (-1 !== line.indexOf(' ')) {
          // console.log('PARSER ERROR :: MALFORMED IMAGE HINTERS INPUT');
          hasParserError = true;
        }
      });
      if (hasParserError) {
        return hasParserError; // return error object instead
      } else {
        return lines;
      }
    }

    /**
     * Chrome sync is really fast, slow down the user
     * @param {Element} formElem - All data from textarea option for image hinters
     * @param {Element} messagesElem - 
     * @param {String} messageMarkup - 
     * @param {String} messageElemId - 
     */

  }, {
    key: 'doSomeSillyUxStuffAfterFormSubmittingSmiley',
    value: function doSomeSillyUxStuffAfterFormSubmittingSmiley(formElem, messagesElem, messageMarkup, messageElemId) {
      var loaderTimerId = window.setTimeout(function () {
        formElem.classList.remove('loading');
        messagesElem.insertAdjacentHTML('afterbegin', messageMarkup);
        var messageRemoverTimerId = window.setTimeout(function () {
          document.getElementById('' + messageElemId).remove();
          window.clearTimeout(messageRemoverTimerId);
        }, 3000);
        window.clearTimeout(loaderTimerId);
      }, 500);
    }

    /**
     * Update browser action bagde status text
     * @param {boolean} isInterceptorEnabled - Interceptor's current status 
     */

  }, {
    key: '_updateBadgeStatus',
    value: function _updateBadgeStatus(isInterceptorEnabled) {
      var badgeText = isInterceptorEnabled ? 'on' : 'off';
      chrome.browserAction.setBadgeText({ text: badgeText });
    }

    /**
     * Finds line breaks and return splitted array from textarea input string
     * @param {string} text - Text to be parsed
     * @return {array} Splitted and trimmed lines array
     */

  }, {
    key: '_findLineBreaks',
    value: function _findLineBreaks(text) {
      var lines = text.split(/\r|\n|\r\n/g);
      lines = lines.filter(function (line) {
        return '' !== line.trim() && !/^(?:\s+)?#/g.test(line);
      }).map(function (line) {
        return line.trim();
      });
      return lines;
    }
  }]);

  return Utils;
}();

exports.Utils = Utils;

/***/ })
/******/ ]);
//# sourceMappingURL=utils.js.map